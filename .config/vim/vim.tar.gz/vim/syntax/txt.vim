if exists('b:current_syntax') 
  finish 
endif

syn region txtComment start="//" skip="\\$" end="$" keepend

hi def link txtComment Comment

let b:current_syntax = 'txt'
